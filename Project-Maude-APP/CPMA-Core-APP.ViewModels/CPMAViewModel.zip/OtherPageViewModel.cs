﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using Prism.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static CPMA_Core_APP.Common.StaticVariables.Pages;

namespace CPMA_Core_APP.ViewModels
{
    public class $safeitemname$ : ViewModelBase
    {
        public $safeitemname$(INavigationService navigationService, IPageDialogService dialogService)
            : base(navigationService, dialogService)
        {
        }

        public override void Load()
        {
        }
    }
}
